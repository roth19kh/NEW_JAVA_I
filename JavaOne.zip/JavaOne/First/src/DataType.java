public class DataType {
    public static void main(String[] args) {
        byte b=-12;
        float f = 34.89f;
        double d = 34.89;
        char a = 'S';
        String st;
        boolean x;
        System.out.println("Tharoth: "+(d));
        String pf = "Tharoth";
    }
}

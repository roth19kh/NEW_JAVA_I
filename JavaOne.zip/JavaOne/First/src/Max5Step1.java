import java.util.Scanner;

public class Max5Step1 {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        int a,b,c,d,e;
        System.out.println("Enter A:");
        a = cin.nextInt();
        System.out.println("Enter B:");
        b = cin.nextInt();
        System.out.println("Enter C:");
        c = cin.nextInt();
        System.out.println("Enter D:");
        d = cin.nextInt();
        System.out.println("Enter E:");
        e = cin.nextInt();


    }
}
